<template>
    <div class="container">
        <NuxtLink to="/">Go Back</NuxtLink>
        <Nuxt />
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>
.container{
    padding: 5rem 0px;
}
</style>