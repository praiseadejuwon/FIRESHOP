
<template>
    <div class="container">
        <PageNotFound />
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>
    .container {
       display: flex;
       justify-content: center;
       align-items: center;
        padding: 4rem 0;
        
    }
</style>